@extends('layouts.headerpop3')

@section('content7')

<div class="main">
    <div class="header">
        <div class="name"><h1><a href="index.html"><img src="img/like/logo.png" width="250"></a></h1></div>
        <form>
            <input type="text" placeholder="Искать здесь...">
            <button type="submit"><img class="lupa" src="img/like/lupa.svg" width="30"></button>
        </form>
        <p></p>
    </div>
    <div class="nad-content-center">
        <ul>
            <li id="txtjir">Фильтры:</li>
            <a href=""><li>Недавнее</li></a>
            <a href="popular.html"><li>Популярное</li></a>
            <a href=""><li>Категории</li></a>
        </ul>
    </div>
</div>
<div class="content-center">
    <h1>Новость</h1>
    <section class="cnt_h1">
        <h1>Начало стройки многофункционального дома</h1>
    </section>
    <section class="cnt_img">
        <img class="cnt_1" src="img/like/home.png" width="285" height="202">
    </section>
    <section class="cnt_p">
        <p>К середине 2020 года был план по постройке универсального дома и разработка, а так же стройка
            начнутся не ранее 2029 года, так как данный проект имеет высокую сложность, то и строиться он будет
            около 10-15 лет. Планируется расширенное помещение в каждой квартире до 150 квадратов, а так же в
            каждой квартире будет до 10 помещений включая комнаты, туалет с ванной, коридоры и так же "Потайные
            комнаты", да-да, вы не ослышились.До встречи в 2029!!! </p>
    </section>
</div>
<div class="content-left">
    <a href=""><img src="img/like/kolokol.svg" width="25"></a>
    <a href="http://localhost:63342/%D0%9F%D1%80%D0%BE%D0%B5%D0%BA%D1%82/like_it.html?_ijt=thhm7h1tjajcp7vtmtua88v6c5"><img
            src="img/like/like.svg" width="25"></a>
    <a href="friend.html"><img src="img/like/friends.svg" width="25"></a>
    <a href="settigs.html"><img src="img/like/settings.svg" width="25"></a>
    <a href=""><img src="img/like/non.svg" width="25"></a>
</div>
<div class="content-right">
    <div class="nad-content-right">
        <div class="I">
            <a href=""><img src="img/like/I.jpg" width="60"></a>
        </div>
        <div class="exit">
            <a href="reg"><img src="img/like/exit.svg" width="25"></a>
        </div>
    </div>
</div>

@endsection
