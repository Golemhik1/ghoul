@extends('layouts.headerpop2')

@section('content6')

<div class="main">
    <div class="header">
        <div class="name"><h1><a href="index.html"><img src="img/like/logo.png" width="250"></a></h1></div>
        <form>
            <input type="text" placeholder="Искать здесь...">
            <button type="submit"><img class="lupa" src="img/like/lupa.svg" width="30"></button>
        </form>
        <p></p>
    </div>
    <div class="nad-content-center">
        <ul>
            <li id="txtjir">Фильтры:</li>
            <a href=""><li>Недавнее</li></a>
            <a href="popular.html"><li>Популярное</li></a>
            <a href=""><li>Категории</li></a>
        </ul>
    </div>
    <div class="content-center">
        <h1>Новость</h1>
        <section class="cnt_h1">
            <h1>Популярный игровой проект Little Nightmares II</h1>
        </section>
        <section class="cnt_img">
            <img class="cnt_1" src="img/like/little-nightmares.jpg" width="285" height="202">
        </section>
        <section class="cnt_p">
            <p>Мультиплатформенная компьютерная игра в жанре платформера с элементами квеста и хоррора
                показывает высоты и дает понять человечеству, что век технологий становится все выше и выше. Наши
                разработчики вложили душу и все свои силы в этот проект, эта игра заставляет углубиться в
                фентезийный мир экшена и хоррор приключений. Бета тест происходил совсем недавно и многие из игроков
                уже получили море удовольствия, поэтому скачивайте и играйте, не пожалеете. </p>
        </section>
    </div>
</div>
<div class="content-left">
    <a href=""><img src="img/like/kolokol.svg" width="25"></a>
    <a href="http://localhost:63342/%D0%9F%D1%80%D0%BE%D0%B5%D0%BA%D1%82/like_it.html?_ijt=thhm7h1tjajcp7vtmtua88v6c5"><img
            src="img/like/like.svg" width="25"></a>
    <a href="friend.html"><img src="img/like/friends.svg" width="25"></a>
    <a href="settigs.html"><img src="img/like/settings.svg" width="25"></a>
    <a href=""><img src="img/like/non.svg" width="25"></a>
</div>
<div class="content-right">
    <div class="nad-content-right">
        <div class="I">
            <a href=""><img src="img/like/I.jpg" width="60"></a>
        </div>
        <div class="exit">
            <a href="reg"><img src="img/like/exit.svg" width="25"></a>
        </div>
    </div>
</div>

@endsection
