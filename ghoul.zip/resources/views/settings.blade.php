@extends('layouts.headersettings')

@section('content9')

<div class="main">
    <div class="header">
        <div class="name"><h1><a href="index.html"><img src="img/like/logo.png" width="250"></a></h1></div>
        <form>
            <input type="text" placeholder="Искать здесь...">
            <button type="submit"><img class="lupa" src="img/like/lupa.svg" width="30"></button>
        </form>
        <p></p>
    </div>
</div>
<div class="content-center">
    <div class="content-center-p">
        <h1>Добавление своих новостей</h1>
        <form>
            <input type="text" placeholder="Запись...">
        </form>
    </div>

</div>
<div class="content-left">
    <a href=""><img src="img/like/kolokol.svg" width="25"></a>
    <a href="http://localhost:63342/%D0%9F%D1%80%D0%BE%D0%B5%D0%BA%D1%82/like_it.html?_ijt=thhm7h1tjajcp7vtmtua88v6c5"><img
            src="img/like/like.svg" width="25"></a>
    <a href="friend.html"><img src="img/like/friends.svg" width="25"></a>
    <a href="settigs.html"><img src="img/like/settings.svg" width="25"></a>
    <a href=""><img src="img/like/non.svg" width="25"></a>
</div>
<div class="content-right">
    <div class="nad-content-right">
        <div class="I">
            <a href=""><img src="img/like/I.jpg" width="60"></a>
        </div>
        <div class="exit">
            <a href="reg"><img src="img/like/exit.svg" width="25"></a>
        </div>
    </div>
</div>

@endsection
