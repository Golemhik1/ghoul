@extends('layouts.headerpop1')

@section('content5')

<div class="main">
    <div class="header">
        <div class="name"><h1><a href="index.html"><img src="img/like/logo.png" width="250"></a></h1></div>
        <form>
            <input type="text" placeholder="Искать здесь...">
            <button type="submit"><img class="lupa" src="img/like/lupa.svg" width="30"></button>
        </form>
        <p></p>
    </div>
    <div class="nad-content-center">
        <ul>
            <li id="txtjir">Фильтры:</li>
            <a href=""><li>Недавнее</li></a>
            <a href="popular.html"><li>Популярное</li></a>
            <a href=""><li>Категории</li></a>
        </ul>
    </div>
    <div class="content-center">
        <h1>Новость</h1>
        <div class="content-one">
            <section class="cnt_h1">
                <h1>Обьявление сезона охоты на обезьян</h1>
            </section>
            <section class="cnt_img">
                <img class="cnt_1" src="img/like/makaka.jpg" width="285" height="202">
            </section>
            <section class="cnt_p">
                <p>Началась осень и обьявляется сезон охоты, мирные граждане в негодовании и хотят запретить такое
                    живодерство вымирающих животных, для этого органы ППВ по спасению и сохранению животных хотят
                    организовать ловлю преступников совершающих такие ужасные деяния с животными. ППВ - Природа привыше
                    всего, этот слоган должен быть у нас всех, все мы должны понимать насколько важна природа и ее
                    обитатели, которые приносят мир и жизнь в наши с вами жизни. По закону УК.Рф статьи №48 пункта 3:
                    Живодерство будет караться по всей строгости, штрафом от 100000 тыс.руб и от 1 до 3 лет лишения
                    свободы. Мы призываем вас всех помочь найти приступников и очистить этот мир от зла! </p>
            </section>
        </div>
    </div>
    <div class="content-left">
        <a href=""><img src="img/like/kolokol.svg" width="25"></a>
        <a href="http://localhost:63342/%D0%9F%D1%80%D0%BE%D0%B5%D0%BA%D1%82/like_it.html?_ijt=thhm7h1tjajcp7vtmtua88v6c5"><img
                src="img/like/like.svg" width="25"></a>
        <a href="friend.html"><img src="img/like/friends.svg" width="25"></a>
        <a href="settigs.html"><img src="img/like/settings.svg" width="25"></a>
        <a href=""><img src="img/like/non.svg" width="25"></a>
    </div>
    <div class="content-right">
        <div class="nad-content-right">
            <div class="I">
                <a href=""><img src="img/like/I.jpg" width="60"></a>
            </div>
            <div class="exit">
                <a href="reg"><img src="img/like/exit.svg" width="25"></a>
            </div>
        </div>
    </div>
</div>

@endsection
