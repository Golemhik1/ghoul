<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>VideoHost</title>

    <link rel="stylesheet" href="css/style_2.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=PT+Sans:wght@400;700&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=PT+Sans:wght@400;700&family=Roboto:wght@700&display=swap"rel="stylesheet">
</head>
<body>
@yield("content2")
</body>
</html>
