<?php

use App\Http\Controllers\FriendController;
use App\Http\Controllers\IndexController;
use App\Http\Controllers\LikeController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\Pop1Controller;
use App\Http\Controllers\Pop2Controller;
use App\Http\Controllers\Pop3Controller;
use App\Http\Controllers\PopularController;
use App\Http\Controllers\RegController;
use App\Http\Controllers\SettingsController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [IndexController::class, 'Index']);
Route::get('/friend', [FriendController::class, 'Index']);
Route::get('/like', [LikeController::class, 'Index']);
Route::get('/pop1', [Pop1Controller::class, 'Index']);
Route::get('/pop2', [Pop2Controller::class, 'Index']);
Route::get('/pop3', [Pop3Controller::class, 'Index']);
Route::get('/popular', [PopularController::class, 'Index']);
Route::get('/reg', [RegController::class, 'Index']);
Route::post('/reg', [RegController::class, 'create']);
Route::get('/settings', [SettingsController::class, 'Index']);

Route::get('/login', function (){
    if(Auth::check()){
        return redirect(route('/'));
    }
    return view('index');
})->name('login');
Route::post('/login', [LoginController::class, 'login']);
