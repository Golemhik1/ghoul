<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>VideoHost</title>

    <link rel="stylesheet" href="css/login_style.css">
    <link rel="preconnect" href="https://fonts.gstatic.com/%22%3E
    <link href="https://fonts.googleapis.com/css2?family=PT+Sans:wght@400;700&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.gstatic.com/%22%3E
    <link href="https://fonts.googleapis.com/css2?family=PT+Sans:wght@400;700&family=Roboto:wght@700&display=swap%22rel=%22stylesheet%22%3E
</head>
<body>
<?php echo $__env->yieldContent('content10'); ?>
</body>
</html><?php /**PATH D:\ghoul\resources\views/layouts/headerLogin.blade.php ENDPATH**/ ?>