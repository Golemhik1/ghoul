

<?php $__env->startSection('content10'); ?>
    <div class="main">
        <div class="container">
            <div class="reg_window">
                <div class="content">
                    <h1>Вход</h1>
                    <form action="">
                        <h3>Введите имя</h3>
                        <p>
                            <input type="text" name="name" placeholder="" required>
                        </p>
                        <h3>Введите пароль</h3>
                        <p>
                            <input type="password" name="password" placeholder="">
                        </p>
                        <button>Войти</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.headerLogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ghoul\resources\views/login.blade.php ENDPATH**/ ?>