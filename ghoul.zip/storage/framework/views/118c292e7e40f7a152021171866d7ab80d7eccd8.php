<?php $__env->startSection('content'); ?>


<div class="main">
    <div class="header">
        <div class="name"><h1><a href="index.html"><img src="img/like/logo.png" width="250"></a></h1></div>
        <form>
            <input type="text" placeholder="Искать здесь...">
            <button type="submit"><img class="lupa" src="img/like/lupa.svg" width="30"></button>
        </form>
        <p></p>
    </div>
    <div class="nad-content-center">
        <ul>
            <li id="txtjir">Фильтры:</li>
            <ul>
                <a href="#"><li>Недавнее</li></a>
                <a href="popular.html"><li>Популярное</li></a>
                <a href="#"><li>Категории</li></a>
            </ul>
    </div>
    <div class="content-center">
        <div class="content-center-p">
            <p>Новости</p>
        </div>
        <div class="content-one">
            <img class="cnt_1" src="img/like/makaka.jpg" width="285" height="202">
            <div class="cnt_2">
                <a href="pop1.html"><h1>Обьявление сезона охоты на обезьян</h1></a>
                <p>Началась осень и обьявляется сезон охоты, мирные граждане в негодовании и хотят запретить такое
                    живодерство...</p>
                <br>
                <br>
                <span class="tag_purple" id="txtpurple1">акунаматата</span>
                <span class="tag_blue" id="txtblue1">вмиреживотных</span>
                <span class="tag_green" id="txtgreen1">природа</span>
            </div>
            <div class="cnt_3">
                <div class="up_cnt">
                    <div class="stars">
                        <img src="img/like/2star.png" width="70">
                    </div>
                    <div class="Rate">
                        <p> 2 </p>
                    </div>
                </div>
                <div class="down_cnt">
                    <img src="img/like/glaz.svg" width="20">
                    <p> 1278 </p>
                </div>
            </div>
        </div>
        <div class="content-two">
            <img class="cnt_1" src="img/like/little-nightmares.jpg" width="270" height="210">
            <div class="cnt_2">
                <a href="pop2.html"><h1>Популярный игровой проект Little Nightmares II</h1></a>
                <p>Мультиплатформенная компьютерная игра в жанре платформера с элементами квеста и хоррора
                    показывает высоты и...</p>
                <br>
                <br>
                <span class="tag_purple" id="txtpurple2">gaming сфера</span>
                <span class="tag_blue" id="txtblue2">одиночная</span>
                <span class="tag_green" id="txtgreen2">хоррор</span>
            </div>
            <div class="cnt_3">
                <div class="up_cnt">
                    <div class="stars">
                        <img src="img/like/4star.png" width="70">
                    </div>
                    <div class="Rate">
                        <p> 4 </p>
                    </div>
                </div>
                <div class="down_cnt">
                    <img src="img/like/glaz.svg" width="20">
                    <p> 23457 </p>
                </div>
            </div>
        </div>
        <div class="content-three">
            <img class="cnt_1" src="img/like/home.png" width="285" height="202">
            <div class="cnt_2">
                <a href="pop3.html"><h1>Начало стройки многофункционального дома</h1></a>
                <p>К середине 2020 года был план по постройке универсального дома и разработка, а так же стройка начнутся не
                    ранее...</p>
                <br>
                <br>
                <span class="tag_purple" id="txtpurple3">архитектура</span>
                <span class="tag_blue" id="txtblue3">строения</span>
                <span class="tag_green" id="txtgreen3">будущее</span>
            </div>
            <div class="cnt_3">
                <div class="up_cnt">
                    <div class="stars">
                        <img src="img/like/1star.png" width="70">
                    </div>
                    <div class="Rate">
                        <p> 1 </p>
                    </div>
                </div>
                <div class="down_cnt">
                    <img src="img/like/glaz.svg" width="20">
                    <p> 1782 </p>
                </div>
            </div>
        </div>
    </div>
    <div class="content-left">
        <a href=""><img src="img/like/kolokol.svg" width="25"></a>
        <a href="http://localhost:63342/%D0%9F%D1%80%D0%BE%D0%B5%D0%BA%D1%82/like_it.html?_ijt=thhm7h1tjajcp7vtmtua88v6c5"><img
                src="img/like/like.svg" width="25"></a>
        <a href="friend.html"><img src="img/like/friends.svg" width="25"></a>
        <a href="settigs.html"><img src="img/like/settings.svg" width="25"></a>
        <a href=""><img src="img/like/non.svg" width="25"></a>
    </div>
    <div class="content-right">
        <a href="https://mcdonalds.ru/"><img src="img/like/reklama.jpg" width="287" height="635px"></a>
        <a href="https://burgerking.ru/"><img src="img/like/reklama2.jpg" width="287" height="203px"></a>
        <div class="nad-content-right">
            <div class="I">
                <a href=""><img src="img/like/I.jpg" width="60"></a>
            </div>
            <div class="exit">
                <a href="reg"><img src="img/like/exit.svg" width="25"></a>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.headerindex', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH Z:\ghoul\resources\views/index.blade.php ENDPATH**/ ?>