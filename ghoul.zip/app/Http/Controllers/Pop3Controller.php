<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Pop3Controller extends Controller
{
    public function index()
    {
        return view('pop3');
    }
}
